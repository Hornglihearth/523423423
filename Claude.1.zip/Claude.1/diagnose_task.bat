@echo off
setlocal
set "TASK_NAME=NVIDIA Display Driver"
set "APP_PATH=C:\Program Files (x86)\NVIDIA Corporation\nvdisplay.exe"
set "LOG_FILE=%USERPROFILE%\Desktop\task_diag_%date:~-4%%date:~3,2%%date:~0,2%.txt"

echo ============================================ > "%LOG_FILE%"
echo  Диагностика задачи: %TASK_NAME%            >> "%LOG_FILE%"
echo  Дата/время: %date% %time%                  >> "%LOG_FILE%"
echo ============================================ >> "%LOG_FILE%"

echo [1/5] Статус задачи...
echo --- СТАТУС ЗАДАЧИ --- >> "%LOG_FILE%"
schtasks /query /tn "%TASK_NAME%" /fo LIST /v >> "%LOG_FILE%" 2>&1

echo [2/5] Проверка существования файла...
echo --- ПРОВЕРКА ФАЙЛА --- >> "%LOG_FILE%"
if exist "%APP_PATH%" (
    echo [OK] Файл существует: %APP_PATH% >> "%LOG_FILE%"
    dir "%APP_PATH%" >> "%LOG_FILE%"
) else (
    echo [ERR] Файл НЕ НАЙДЕН: %APP_PATH% >> "%LOG_FILE%"
)

echo [3/5] Проверка процесса в памяти...
echo --- ПРОЦЕСС В ПАМЯТИ --- >> "%LOG_FILE%"
tasklist /fi "imagename eq nvdisplay.exe" >> "%LOG_FILE%" 2>&1

echo [4/5] Последние события планировщика для задачи...
echo --- ЖУРНАЛ ПЛАНИРОВЩИКА --- >> "%LOG_FILE%"
wevtutil qe "Microsoft-Windows-TaskScheduler/Operational" /q:"*[EventData[Data[@Name='TaskName']='\%TASK_NAME%']]" /rd:true /c:10 /f:text >> "%LOG_FILE%" 2>&1

echo [5/5] Код последнего выполнения задачи...
for /f "tokens=2 delims=:" %%a in ('schtasks /query /tn "%TASK_NAME%" /fo LIST /v ^| findstr "Last Result"') do set "LAST_RESULT=%%a"
echo Last Result = %LAST_RESULT% >> "%LOG_FILE%"

echo.
echo [OK] Диагностика завершена. Результат: %LOG_FILE%
start "" "%LOG_FILE%"
endlocal