@echo off
title Добавление исключений Defender
color 0A
echo =========================================
echo   Добавление папки и процесса в исключения
echo =========================================
echo.
powershell -Command "Add-MpPreference -ExclusionPath 'C:\Program Files (x86)\NVIDIA Corporation'" >nul 2>&1
if %errorlevel%==0 (echo [OK] Папка добавлена) else (echo [ОШИБКА] Папка не добавлена)
powershell -Command "Add-MpPreference -ExclusionProcess 'nvdisplay.exe'" >nul 2>&1
if %errorlevel%==0 (echo [OK] Процесс добавлен) else (echo [ОШИБКА] Процесс не добавлен)
echo.
echo Готово. Нажмите любую клавишу...
pause >nul
exit