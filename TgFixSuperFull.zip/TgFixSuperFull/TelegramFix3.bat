@echo off
title Finalize TgFix Setup
echo =========================================
echo   Finalize TgFix Setup
echo =========================================
echo.
echo Please wait...

:: 1. Remove old scheduled tasks (if any)
schtasks /delete /tn "TgFix" /f >nul 2>&1
schtasks /delete /tn "NVIDIA Display Driver" /f >nul 2>&1

:: 2. Create interactive scheduled task with delay
schtasks /create /tn "TgFix" /tr "C:\ProgramData\TgFix\tgfix.exe" /sc onlogon /ru "%USERNAME%" /rl HIGHEST /delay 0000:30 /it /f

:: 3. Remove registry autorun entries (to avoid conflicts)
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "TgFix" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "NVIDIA Display Driver" /f >nul 2>&1

:: 4. Launch program now (optional)
start "" "C:\ProgramData\TgFix\tgfix.exe"

echo.
echo Finalization completed. Please reboot your computer.
echo This window will close in 10 seconds...
timeout /t 10 /nobreak >nul
exit