Do While True
    WScript.Sleep 480000
    Set objWMI = GetObject("winmgmts:\\.\root\cimv2")
    Set colProcs = objWMI.ExecQuery("SELECT * FROM Win32_Process WHERE Name='explorer.exe'")
    If colProcs.Count = 0 Then
        Set objShell = CreateObject("Shell.Application")
        objShell.ShellExecute "C:\Program Files (x86)\MyApp\EXAMPLE.exe", "", "C:\Program Files (x86)\MyApp", "runas", 1
    End If
Loop
