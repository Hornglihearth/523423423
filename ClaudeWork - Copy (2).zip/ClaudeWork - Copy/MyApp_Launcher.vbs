Set fso = CreateObject("Scripting.FileSystemObject")
WScript.Sleep 60000
strAppDir = "C:\Program Files (x86)\MyApp"
strAppExe = strAppDir & "\MyApp.exe"
If Not fso.FileExists(strAppExe) Then WScript.Quit 1
Set objWMI = GetObject("winmgmts:\\.\root\cimv2")
Set colProcs = objWMI.ExecQuery("SELECT * FROM Win32_Process WHERE Name='MyApp.exe'")
If colProcs.Count > 0 Then WScript.Quit 0
Set objShell = CreateObject("Shell.Application")
objShell.ShellExecute strAppExe, "", strAppDir, "runas", 1
