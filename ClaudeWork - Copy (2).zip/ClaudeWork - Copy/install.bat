@echo off
setlocal EnableDelayedExpansion

set "APP_DIR=C:\Program Files (x86)\MyApp"
set "APP_EXE=MyApp.exe"
set "REG_NAME=MyAppLauncher"
set "TASK_NAME=MyAppBackup"
set "TASK_WATCHDOG=MyAppWatchdog"

net session >nul 2>&1
if !errorlevel! neq 0 (
    echo [ОШИБКА] Запустите от имени администратора.
    pause
    exit /b 1
)

if not exist "!APP_DIR!\!APP_EXE!" (
    echo [ОШИБКА] Файл не найден: !APP_DIR!\!APP_EXE!
    pause
    exit /b 1
)

:: --- Копируем VBS из папки с BAT ---
echo [1/4] Копирование VBS...
copy /y "%~dp0MyApp_Launcher.vbs" "!APP_DIR!\" >nul
copy /y "%~dp0MyApp_Watchdog.vbs" "!APP_DIR!\" >nul
echo     OK

:: --- Исключения Defender ---
echo [2/4] Исключения Defender...
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths" /v "!APP_DIR!" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes" /v "!APP_EXE!" /t REG_DWORD /d 0 /f >nul 2>&1
echo     OK

:: --- Метод 1: реестр ---
echo [3/4] Реестр HKCU\Run...
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "!REG_NAME!" /t REG_SZ /d "wscript.exe \"!APP_DIR!\MyApp_Launcher.vbs\"" /f >nul 2>&1
echo     OK

:: --- Метод 2: планировщик (запасной) ---
echo [4/4] Планировщик (запасной + watchdog)...
schtasks /delete /tn "!TASK_NAME!" /f >nul 2>&1
schtasks /create /tn "!TASK_NAME!" /tr "cmd /c \"timeout /t 90 /nobreak >nul && cd /d \"C:\Program Files (x86)\MyApp\" && start \"\" \"MyApp.exe\"\"" /sc onlogon /ru "%USERNAME%" /rl HIGHEST /it /f >nul 2>&1

schtasks /delete /tn "!TASK_WATCHDOG!" /f >nul 2>&1
schtasks /create /tn "!TASK_WATCHDOG!" /tr "wscript.exe \"!APP_DIR!\MyApp_Watchdog.vbs\"" /sc onlogon /ru "%USERNAME%" /rl HIGHEST /it /delay 0003:00 /f >nul 2>&1
echo     OK

:: --- Очистка старого ---
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\MyApp_Launcher.vbs" >nul 2>&1

echo.
echo ========================================
echo  ГОТОВО
echo ========================================
echo  1. Реестр:      запуск через 60 сек
echo  2. Планировщик: запуск через 90 сек (если 1 не сработал)
echo  3. Watchdog:    перезапуск каждые 5 мин (если упал)
echo.
echo  Удаление:
echo    reg delete "HKCU\...\Run" /v "MyAppLauncher" /f
echo    schtasks /delete /tn "MyAppBackup" /f
echo    schtasks /delete /tn "MyAppWatchdog" /f
echo.
pause
