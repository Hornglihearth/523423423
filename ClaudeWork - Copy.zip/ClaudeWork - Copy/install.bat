@echo off
:: Запускать от имени администратора
:: Работает на Windows 10/11 и Server 2022

set "APP_DIR=C:\Program Files\MyApp"
set "APP_EXE=myapp.exe"
set "VBS_NAME=MyApp_Launcher.vbs"
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "VBS_PATH=%STARTUP_DIR%\%VBS_NAME%"
set "DELAY_SEC=60"

:: --- Проверка прав администратора ---
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [ОШИБКА] Запустите от имени администратора.
    pause
    exit /b 1
)

:: --- Проверка наличия приложения ---
if not exist "%APP_DIR%\%APP_EXE%" (
    echo [ОШИБКА] Файл %APP_DIR%\%APP_EXE% не найден.
    pause
    exit /b 1
)

:: --- Добавление исключений Defender ---
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths" /v "%APP_DIR%" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes" /v "%APP_EXE%" /t REG_DWORD /d 0 /f >nul 2>&1

:: --- Создание VBS-лаунчера ---
(
echo ' MyApp Launcher - запуск с правами администратора
echo ' Задержка %DELAY_SEC% сек для полной загрузки рабочего стола
echo.
echo Set WshShell = CreateObject^("WScript.Shell"^)
echo Set fso = CreateObject^("Scripting.FileSystemObject"^)
echo.
echo ' Задержка
echo WScript.Sleep %DELAY_SEC% * 1000
echo.
echo ' Путь к приложению
echo strAppDir = "%APP_DIR%"
echo strAppExe = strAppDir ^& "\%APP_EXE%"
echo.
echo ' Проверка существования файла
echo If Not fso.FileExists^(strAppExe^) Then
echo     WScript.Quit 1
echo End If
echo.
echo ' Проверка: не запущен ли уже процесс
echo Set objWMI = GetObject^("winmgmts:\\.\root\cimv2"^)
echo Set colProcs = objWMI.ExecQuery^("SELECT * FROM Win32_Process WHERE Name='%APP_EXE%'"^)
echo If colProcs.Count ^> 0 Then
echo     WScript.Quit 0
echo End If
echo.
echo ' Запуск с правами администратора (UAC-промпт подавлен, т.к. UAC отключён)
echo Set objShell = CreateObject^("Shell.Application"^)
echo objShell.ShellExecute strAppExe, "", strAppDir, "runas", 1
) > "%VBS_PATH%"

echo.
echo [OK] Лаунчер создан: %VBS_PATH%
echo     - Приложение: %APP_DIR%\%APP_EXE%
echo     - Задержка:   %DELAY_SEC% сек
echo     - Метод:      ShellExecute runas (интерактивный сеанс)
echo.
echo При входе пользователя VBS запустится автоматически из Startup,
echo подождёт %DELAY_SEC% сек и запустит %APP_EXE% с правами администратора.
echo.
pause
